Data struture in c language
